A documentacion do proxecto
***************************

Documentamos o proxecto en Restructure text