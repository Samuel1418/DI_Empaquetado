def imprimeAlgo2():
    print("Imprimo algo no paquete, eo seu nome: ", __name__)
