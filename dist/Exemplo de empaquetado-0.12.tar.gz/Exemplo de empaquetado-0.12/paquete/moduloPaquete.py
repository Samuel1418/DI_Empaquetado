def imprimeAlgo():
    print("Imprimo algo no paquete, eo seu nome: ", __name__)
def main():
    imprimeAlgo()


if __name__ == "__main__":
    main()